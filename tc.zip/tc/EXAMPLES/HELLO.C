// Borland C++ - (C) Copyright 1991 by Borland International

/*	HELLO.C -- Hello, world */

#include <stdio.h>

int main()
{
	printf("Hello, world\n");
	return 0;
}
